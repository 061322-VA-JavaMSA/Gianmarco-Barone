package exceptions;

public class LoginException extends Error {

}
