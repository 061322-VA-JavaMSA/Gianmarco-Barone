package services;

public class OfferService {

}
