package com.revature;

public class divideByZeroException extends RuntimeException{
	public divideByZeroException() {
		
		
	}
	
}
