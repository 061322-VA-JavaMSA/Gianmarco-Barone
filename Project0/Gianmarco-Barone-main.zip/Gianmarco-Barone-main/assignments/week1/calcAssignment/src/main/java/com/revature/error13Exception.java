package com.revature;

public class  error13Exception extends ArithmeticException {
public error13Exception() {
	// TODO Auto-generated constructor stub
	System.out.println("Error number 13 not allowed");
}
}
