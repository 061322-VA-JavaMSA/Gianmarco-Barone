public class randomnumber{

	public static void main(String[] args){

	

	if(args length == 0){
	int num = (int)(Math.random()* Integer.parseInt(args) + 1)
	System.out.println(num)
}	
System.out.println(x);
}

}
